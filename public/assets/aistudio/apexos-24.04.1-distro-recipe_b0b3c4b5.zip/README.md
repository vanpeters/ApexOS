# ApexOS Developer & Gaming Edition v24.04.1
Ubuntu Base: 24.04-lts (noble)
Kernel: linux-xanmod-gaming
Desktop Environment: gnome-47

## Pre-Configured PPA Repositories:
- Ubuntu Official Base & Universe (archive.ubuntu.com/ubuntu)
- Lutris Gaming Platform PPA (ppa:lutris-team/lutris)
- Android Studio IDE PPA (ppa:maarten-fonville/android-studio)
- Anthropic Claude Desktop Repository (deb.anthropic.com/linux)
- OpenAI ChatGPT Desktop Repository (deb.openai.com/linux)
- WineHQ Staging & Proton Runtime (dl.winehq.org/wine-builds/ubuntu)
- Kisak Mesa Fresh Gaming Drivers PPA (ppa:kisak/kisak-mesa)

## How to Build the Bootable ISO:
1. Ensure you have an Ubuntu/Debian system or VM.
2. Make the script executable:
   chmod +x build-iso.sh
3. Run as root:
   sudo ./build-iso.sh
4. Once completed, flash to USB:
   sudo dd if=apexos-24.04.1-amd64.iso of=/dev/sdX bs=4M status=progress oflag=sync
