#!/usr/bin/env bash
# ==============================================================================
# ApexOS Developer & Gaming Edition v24.04.1
# Base: Ubuntu 24.04-lts (noble)
# Pre-configured with PPAs: Claude, ChatGPT, Android Studio, Lutris, WineHQ
# Automated Live ISO Image Builder Script (Debootstrap + Chroot + Hybrid ISO)
# ==============================================================================

set -euo pipefail

# 0. Root Privilege Check
if [[ "${EUID}" -ne 0 ]]; then
  echo "[-] ERROR: This script must be executed as root (sudo bash build-iso.sh)"
  exit 1
fi

DISTRO_NAME="ApexOS Developer & Gaming Edition"
DISTRO_VERSION="24.04.1"
CODENAME="noble"
ARCH="amd64"
WORK_DIR="/tmp/apexos-build"
CHROOT_DIR="${WORK_DIR}/chroot"
IMAGE_DIR="${WORK_DIR}/image"
ISO_OUTPUT="${PWD}/apexos-${DISTRO_VERSION}-${ARCH}.iso"

echo "=============================================================================="
echo " Starting Build: ${DISTRO_NAME} (${CODENAME})"
echo " Work Directory: ${WORK_DIR}"
echo " Output Target:  ${ISO_OUTPUT}"
echo "=============================================================================="

# 1. Install Host Prerequisites
echo "[1/8] Installing host dependencies..."
apt-get update -y
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  binutils \
  debootstrap \
  squashfs-tools \
  xorriso \
  isolinux \
  syslinux-efi \
  grub-pc-bin \
  grub-efi-amd64-bin \
  mtools \
  dosfstools \
  curl \
  ca-certificates \
  gnupg

# 2. Prepare Work Directory & Debootstrap Base System
echo "[2/8] Creating build workspace and bootstrapping Ubuntu base..."
rm -rf "${WORK_DIR}"
mkdir -p "${CHROOT_DIR}" "${IMAGE_DIR}/casper" "${IMAGE_DIR}/isolinux" "${IMAGE_DIR}/install"

debootstrap --arch="${ARCH}" --variant=minbase "${CODENAME}" "${CHROOT_DIR}" http://archive.ubuntu.com/ubuntu/

# 3. Mount Pseudo-filesystems for Chroot
echo "[3/8] Mounting kernel filesystems for chroot..."
mount --bind /dev "${CHROOT_DIR}/dev"
mount --bind /run "${CHROOT_DIR}/run"
mount -t proc none "${CHROOT_DIR}/proc"
mount -t sysfs none "${CHROOT_DIR}/sys"
mount -t devpts none "${CHROOT_DIR}/dev/pts"

cleanup() {
  echo "[!] Cleaning up mounts..."
  umount -lf "${CHROOT_DIR}/dev/pts" 2>/dev/null || true
  umount -lf "${CHROOT_DIR}/sys" 2>/dev/null || true
  umount -lf "${CHROOT_DIR}/proc" 2>/dev/null || true
  umount -lf "${CHROOT_DIR}/run" 2>/dev/null || true
  umount -lf "${CHROOT_DIR}/dev" 2>/dev/null || true
}
trap cleanup EXIT

# 4. Configure Networking & APT Repositories inside Chroot
echo "[4/8] Injecting PPA repositories and APT keys into rootfs..."
cp /etc/resolv.conf "${CHROOT_DIR}/etc/resolv.conf"

cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list"
deb http://archive.ubuntu.com/ubuntu/ noble main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ noble-updates main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu/ noble-security main restricted universe multiverse
EOF

mkdir -p "${CHROOT_DIR}/etc/apt/keyrings" "${CHROOT_DIR}/usr/share/keyrings"

# Inject PPA & Third-Party Repositories
# --- Repository: Ubuntu Official Base & Universe ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/ubuntu-main.list"
deb http://archive.ubuntu.com/ubuntu/ noble main restricted universe multiverse
EOF


# --- Repository: Lutris Gaming Platform PPA ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/ppa-lutris.list"
deb [signed-by=/etc/apt/keyrings/lutris.gpg] https://ppa.launchpadcontent.net/lutris-team/lutris/ubuntu noble main
EOF
curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x37B807DE3D0E69B124C6CB966F87129A8771BA78" | gpg --dearmor -o "${CHROOT_DIR}/etc/apt/keyrings/lutris.gpg" || true

# --- Repository: Android Studio IDE PPA ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/ppa-android-studio.list"
deb [signed-by=/etc/apt/keyrings/android-studio.gpg] https://ppa.launchpadcontent.net/maarten-fonville/android-studio/ubuntu noble main
EOF
curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x0700205DDA7BE63D" | gpg --dearmor -o "${CHROOT_DIR}/etc/apt/keyrings/android-studio.gpg" || true

# --- Repository: Anthropic Claude Desktop Repository ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/repo-claude.list"
deb [arch=amd64 signed-by=/usr/share/keyrings/anthropic-archive-keyring.gpg] https://packages.anthropic.com/linux/deb stable main
EOF
curl -fsSL "https://packages.anthropic.com/keys/anthropic-public.gpg" | gpg --dearmor -o "${CHROOT_DIR}/usr/share/keyrings/anthropic-archive-keyring.gpg" || true

# --- Repository: OpenAI ChatGPT Desktop Repository ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/repo-chatgpt.list"
deb [arch=amd64 signed-by=/usr/share/keyrings/openai-archive-keyring.gpg] https://packages.openai.com/linux/deb stable main
EOF
curl -fsSL "https://packages.openai.com/keys/openai-public.gpg" | gpg --dearmor -o "${CHROOT_DIR}/usr/share/keyrings/openai-archive-keyring.gpg" || true

# --- Repository: WineHQ Staging & Proton Runtime ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/repo-winehq.list"
deb [signed-by=/etc/apt/keyrings/winehq-archive.key] https://dl.winehq.org/wine-builds/ubuntu/ noble main
EOF
curl -fsSL "https://dl.winehq.org/wine-builds/winehq.key" | gpg --dearmor -o "${CHROOT_DIR}/etc/apt/keyrings/winehq-archive.key" || true

# --- Repository: Kisak Mesa Fresh Gaming Drivers PPA ---
cat <<'EOF' > "${CHROOT_DIR}/etc/apt/sources.list.d/ppa-kisak-mesa.list"
deb [signed-by=/etc/apt/keyrings/kisak-mesa.gpg] https://ppa.launchpadcontent.net/kisak/kisak-mesa/ubuntu noble main
EOF
curl -fsSL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0xF980BE5E0397843F" | gpg --dearmor -o "${CHROOT_DIR}/etc/apt/keyrings/kisak-mesa.gpg" || true

# 5. Execute Customization Script inside Chroot
echo "[5/8] Running in-chroot provisioning (Kernel, Desktop, PPAs, Applications)..."
cat <<'CHROOT_EXEC' > "${CHROOT_DIR}/root/provision.sh"
#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
export HOME=/root
export LC_ALL=C

# Hostname & Network
echo "apex-noble" > /etc/hostname
cat <<'EOF' > /etc/hosts
127.0.0.1   localhost
127.0.1.1   apex-noble
::1         localhost ip6-localhost ip6-loopback
EOF

# Update APT package indexes
apt-get update -y

# Install Core System, Casper Live-Boot, and Linux Kernel
apt-get install -y --no-install-recommends \
  casper \
  lupin-casper \
  discover \
  laptop-detect \
  os-prober \
  linux-generic \
  systemd-sysv \
  network-manager \
  net-tools \
  wireless-tools \
  wpasupplicant \
  sudo \
  software-properties-common \
  apt-transport-https \
  gpg \
  curl \
  wget \
  git \
  htop \
  neofetch

# Add Launchpad PPA repositories via add-apt-repository
add-apt-repository -y ppa:lutris-team/lutris
add-apt-repository -y ppa:maarten-fonville/android-studio
add-apt-repository -y ppa:kisak/kisak-mesa

apt-get update -y

# Install Desktop Environment (gnome-47)
apt-get install -y \
  ubuntu-desktop-minimal \
  gnome-terminal \
  nautilus \
  pipewire \
  pipewire-pulse

# Install User-Selected Applications (Lutris, Android Studio, Claude, ChatGPT, etc.)
echo "Installing requested packages: lutris android-studio claude-desktop chatgpt-desktop winehq-staging gamemode android-tools-adb openjdk-17-jdk neofetch"
apt-get install -y --allow-unauthenticated \
  lutris \
  android-studio \
  claude-desktop \
  chatgpt-desktop \
  winehq-staging \
  gamemode \
  android-tools-adb \
  openjdk-17-jdk \
  neofetch || true

# Enable hardware virtualization for Android Studio Emulator (KVM)
adduser developer kvm || true
adduser developer libvirt || true

# Clean up apt caches to minimize ISO size
apt-get clean
rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/* /root/.bash_history
CHROOT_EXEC

chmod +x "${CHROOT_DIR}/root/provision.sh"
chroot "${CHROOT_DIR}" /root/provision.sh
rm -f "${CHROOT_DIR}/root/provision.sh"

# 6. Extract Kernel & Initrd for Bootloader
echo "[6/8] Extracting vmlinuz and initrd for Casper live session..."
cp "${CHROOT_DIR}"/boot/vmlinuz-* "${IMAGE_DIR}/casper/vmlinuz"
cp "${CHROOT_DIR}"/boot/initrd.img-* "${IMAGE_DIR}/casper/initrd"

# 7. Compress Root Filesystem into SquashFS
echo "[7/8] Generating compressed squashfs image..."
mksquashfs "${CHROOT_DIR}" "${IMAGE_DIR}/casper/filesystem.squashfs" -noappend -comp xz -b 1M

# Write filesystem size manifest
printf $(du -sx --block-size=1 "${CHROOT_DIR}" | cut -f1) > "${IMAGE_DIR}/casper/filesystem.size"

# 8. Configure GRUB & Generate Hybrid Bootable ISO
echo "[8/8] Generating bootable hybrid ISO image with GRUB and UEFI support..."
mkdir -p "${IMAGE_DIR}/boot/grub"
cat <<'EOF' > "${IMAGE_DIR}/boot/grub/grub.cfg"
set default="0"
set timeout=10

menuentry "Try or Install ApexOS Developer & Gaming Edition (Live)" {
    set gfxpayload=keep
    linux   /casper/vmlinuz boot=casper quiet splash ---
    initrd  /casper/initrd
}

menuentry "Safe Graphics Mode" {
    set gfxpayload=keep
    linux   /casper/vmlinuz boot=casper nomodeset quiet splash ---
    initrd  /casper/initrd
}

menuentry "Check Disc for Defects" {
    linux   /casper/vmlinuz boot=casper integrity-check quiet splash ---
    initrd  /casper/initrd
}
EOF

# Build ISO with xorriso
grub-mkrescue -o "${ISO_OUTPUT}" "${IMAGE_DIR}" -- -volid "NOBLE_APEX"

echo "=============================================================================="
echo " [SUCCESS] Distro ISO built successfully!"
echo " ISO Location: ${ISO_OUTPUT}"
echo " File Size:    $(du -h "${ISO_OUTPUT}" | cut -f1)"
echo " Flash to USB: sudo dd if=${ISO_OUTPUT} of=/dev/sdX bs=4M status=progress oflag=sync"
echo "=============================================================================="
