#!/usr/bin/env bash
# Post-installation first-boot optimization script for ApexOS Developer & Gaming Edition
set -e

echo "[*] Initializing ApexOS Developer & Gaming Edition first boot setup..."

# 1. Update package indexes
sudo apt-get update -y

# 2. Setup Android Studio SDK directories and permissions
mkdir -p "$HOME/Android/Sdk"
mkdir -p "$HOME/.android"
echo 'export ANDROID_HOME="$HOME/Android/Sdk"' >> "$HOME/.bashrc"
echo 'export PATH="$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin"' >> "$HOME/.bashrc"

# 3. Setup Lutris DXVK cache and Gamemode
mkdir -p "$HOME/Games"
mkdir -p "$HOME/.local/share/lutris/runners/wine"
systemctl --user enable gamemoded.service || true

# 4. Verify Claude and ChatGPT desktop associations
xdg-mime default claude-desktop.desktop x-scheme-handler/claude || true
xdg-mime default chatgpt-desktop.desktop x-scheme-handler/chatgpt || true

echo "[✓] ApexOS optimization complete! Ready to develop and game."
